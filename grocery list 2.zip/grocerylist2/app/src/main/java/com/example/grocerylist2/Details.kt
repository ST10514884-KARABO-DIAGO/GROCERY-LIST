package com.example.grocerylist2

import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class Details : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_details)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        //declarations
        val txitem =findViewById<TextView>(R.id.txitem)
        val txcategory =findViewById<TextView>(R.id.txcategory)
        val textview13 =findViewById<TextView>(R.id.textView13)
        val txquantity =findViewById<TextView>(R.id.txquantity)
        val button =findViewById<Button>(R.id.button)

        //Categories
        val catgories = arrayOf(
            "Sipplies",
            "Beverages",
            "Snacks",
            "Decorations",
            "food"
        )
        //add categories to spinner
        val adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_item,
            catgories
        )

        adapter.setDropDownViewResource(
            android.R.layout.simple_spinner_dropdown_item
        )
        button.setOnClickListener {
            val name =txitem.text.toString()
            val quantity =txcategory.text.toString()
            val comments =textview13.text.toString()

            //error handling
            if (name.isEmpty()){
                txitem.error = "Enter an item name"
                return@setOnClickListener
            }
            if (quantity.isEmpty()) {
                txquantity.error = "Enter an quantity"
                return@setOnClickListener
            }
            if (comments.isEmpty()){
                textview13.error = "Enter a comment"
                return@setOnClickListener
            }
            Toast.makeText(
                this,
                "$name added succesfully!",
                Toast.LENGTH_SHORT
            ).show()
            finish()
        }
    }
}