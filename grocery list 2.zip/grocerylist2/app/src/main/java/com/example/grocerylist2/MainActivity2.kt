package com.example.grocerylist2

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity2 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main2)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        val button3 =findViewById<Button>(R.id.button3)
        val button4 =findViewById<Button>(R.id.button4)
        val tvnum =findViewById<TextView>(R.id.tvnum)

        //Parallel arrays
        var itemNames = arrayOf(
            "Paper Cups",
            "Soda Bottles",
            "Potato Chips"
        )

        var categories = arrayOf(
            "Supplies",
            "Beverages",
            "Snacks"
        )

        var quantities = arrayOf(
            50,
            10,
            5
        )

        var comments = arrayOf(
            "Res ones for the theme",
            "Mix of Cola and Orange",
            "Large bags only"
        )

        //Calculate total using a loop
        var totalItems = 0

        for (i in itemNames.indices) {
            totalItems++
        }

        //Display total
        tvnum.text=totalItems.toString()

        //Add Item button
        button3.setOnClickListener{

            val intent = Intent(this, additem::class.java)
            startActivity(intent)
        }

        //View list button
        button4.setOnClickListener {

            val intent = Intent(this, Details::class.java)
            startActivity(intent)
        }

    }
}